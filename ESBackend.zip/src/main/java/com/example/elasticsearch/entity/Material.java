package com.example.elasticsearch.entity;

import lombok.Data;
import lombok.Getter;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.elasticsearch.annotations.Setting;
@Getter
@Setting
@Data
@Document(indexName = "material_index")
public class Material {

    @Field(index = false, type = FieldType.Keyword)
    private int id;

    @Field(index = true, analyzer = "ik_smart", searchAnalyzer = "ik_smart", type = FieldType.Text)
    private String title;

    @Field(index = true, analyzer = "ik_smart", searchAnalyzer = "ik_smart", type = FieldType.Text)
    private String content;

    public Material() {
    }

    public Material(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

}
