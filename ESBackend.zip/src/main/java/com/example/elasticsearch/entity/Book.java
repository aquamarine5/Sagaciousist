package com.example.elasticsearch.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.List;

//@Document 文档对象 （索引信息、文档类型 ）
@Getter
@Setter
@Data
@Document(indexName = "book_index")
public class Book {

    @Field(index = false, type = FieldType.Keyword)
    private int id;

    @Field(index = true, analyzer = "ik_smart", searchAnalyzer = "ik_smart", type = FieldType.Text)
    private String title;
    //建立索引，text属性才被分词
    @Field(index = true, analyzer = "ik_smart", searchAnalyzer = "ik_smart", type = FieldType.Text)
    private String content;

    //向量
    @Field(index = false, type = FieldType.Dense_Vector, dims = 768)
    private List<Double> vector_field;


    public Book() {
    }

    public Book(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

}

