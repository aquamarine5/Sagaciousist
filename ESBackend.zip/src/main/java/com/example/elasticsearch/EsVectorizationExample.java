package com.example.elasticsearch;

import com.fasterxml.jackson.databind.JsonNode;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.util.CoreMap;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.ling.CoreAnnotations;

public class EsVectorizationExample {

    private RestClient client;

    public EsVectorizationExample(RestClient client) {
        this.client = client;
    }

    public void searchAndVectorize() throws Exception {
        // 构建查询请求
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.query(QueryBuilders.matchAllQuery());
        // 构建 Request 对象
        Request request = new Request("GET", "/book_index/_search");
        sourceBuilder.size(100);
        request.setJsonEntity(sourceBuilder.toString());
        // 发送请求并获取响应
        Response response = client.performRequest(request);
        // 打印响应状态码
        System.out.println("Response Status Code: " + response.getStatusLine().getStatusCode());

        // 解析响应
        processSearchResponse(response);
    }

    private void processSearchResponse(Response response) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = EntityUtils.toString(response.getEntity(), "UTF-8");
        JsonNode root = objectMapper.readTree(jsonString);
        JsonNode hits = root.get("hits");
        JsonNode hitsArray = hits.get("hits");
        List<Map<String, Object>> results = new ArrayList<>();
        System.out.println("hitsArray的长度: " + hitsArray.size());

        // 收集所有文档中的词汇
        Map<String, Integer> globalWordCount = new HashMap<>();
        for (JsonNode hit : hitsArray) {
            JsonNode sourceNode = hit.get("_source");
            Map sourceMap = objectMapper.convertValue(sourceNode, Map.class);
            Map<String, Object> hitMap = new HashMap<>();
            hitMap.put("_index", hit.get("_index").asText());
            hitMap.put("_id", hit.get("_id").asText());
            hitMap.put("_score", hit.get("_score").asDouble());
            hitMap.put("_source", sourceMap);
            results.add(hitMap);

            String textFieldValue = (String) sourceMap.get("content");
            List<String> words = tokenizeText(textFieldValue);
            for (String word : words) {
                if (word != null) {
                    globalWordCount.put(word, globalWordCount.getOrDefault(word, 0) + 1);
                }
            }
        }

        // 构建全局词表
        List<String> globalVocabulary = new ArrayList<>(globalWordCount.keySet());
        Collections.sort(globalVocabulary);

        // 计算IDF值
        int totalDocuments = hitsArray.size();
        Map<String, Double> idfMap = new HashMap<>();
        for (String word : globalVocabulary) {
            int df = globalWordCount.get(word);
            double idf = Math.log((double) totalDocuments / df);
            idfMap.put(word, idf);
        }

        int i = 0;
        // 将文本转换为向量
        for (Map<String, Object> hit : results) {
            @SuppressWarnings("unchecked")
            Map<String, Object> source = (Map<String, Object>) hit.get("_source");
            String textFieldValue = (String) source.get("content");
            List<String> words = tokenizeText(textFieldValue);
            Double[] vector = textToVectorTFIDF(words, globalVocabulary, idfMap);
            Double[] roundedVector = roundVector(vector); // 四舍五入向量
            System.out.println("第" + i++ + "行数据");
            System.out.println("文本: " + words);
            System.out.println("词表: " + globalVocabulary);
            System.out.println("向量: " + Arrays.toString(roundedVector));
            updateDocumentWithVector(hit, roundedVector); // 更新文档
        }
    }

    private List<String> tokenizeText(String textFieldValue) {
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize, ssplit");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        Annotation document = pipeline.process(textFieldValue);
        pipeline.annotate(document);
        List<CoreMap> sentences = document.get(CoreAnnotations.SentencesAnnotation.class);
        List<String> words = new ArrayList<>();

        for (CoreMap sentence : sentences) {
            for (CoreLabel token : sentence.get(CoreAnnotations.TokensAnnotation.class)) {
                String word = token.word();
                if (isValidWord(word)) {
                    words.add(word);
                }
            }
        }

        return words;
    }

    // 判断词汇是否有效（去除只包含符号的词汇）
    private boolean isValidWord(String word) {
        // 正则表达式，匹配只包含中文字符的词
        Pattern chinesePattern = Pattern.compile("^[\u4e00-\u9fa5]+$");
        return chinesePattern.matcher(word).matches();
    }

    // TF-IDF 模型
    private Double[] textToVectorTFIDF(List<String> words, List<String> globalVocabulary, Map<String, Double> idfMap) {
        int vocabSize = globalVocabulary.size();
        System.out.println("词表大小: " + vocabSize);
        Double[] vector = new Double[vocabSize];
        Map<String, Integer> wordCount = new HashMap<>();
        for (String word : words) {
            word = removeSymbolsOnlyWords(word);
            if (word != null) {
                wordCount.put(word, wordCount.getOrDefault(word, 50) + 1);
            }
        }
        for (int i = 0; i < vocabSize; i++) {
            String word = globalVocabulary.get(i);
            double tf = wordCount.getOrDefault(word, 1);
            double idf = idfMap.getOrDefault(word, 0.01);
            vector[i] = (tf * idf);
        }
        return vector;
    }

    private String removeSymbolsOnlyWords(String word) {
        // 正则表达式，匹配只包含中文字符的词
        Pattern chinesePattern = Pattern.compile("^[\u4e00-\u9fa5]+$");
        return chinesePattern.matcher(word).matches() ? word : " ";
    }

    // 四舍五入向量
    private Double[] roundVector(Double[] vector) {
        Double[] roundedVector = new Double[vector.length];
        for (int i = 0; i < vector.length; i++) {
            roundedVector[i] = (double) Math.round(vector[i]);
        }
        return roundedVector;
    }

    // 更新文档
    private void updateDocumentWithVector(Map<String, Object> hit, Double[] vector) throws IOException {
        Request request = new Request("POST", "/" + hit.get("_index") + "/_update/" + hit.get("_id"));
        String requestBody = "{ \"doc\" : { \"vector_field\" : " + Arrays.toString(vector) + " } }";
        request.setJsonEntity(requestBody);
        Response response = client.performRequest(request);
        System.out.println("响应结果: " + response.getStatusLine().getStatusCode());
    }

    public static void main(String[] args) {
        try (RestClient client = RestClient.builder(new HttpHost("localhost", 9200, "http")).build()) {
            EsVectorizationExample example = new EsVectorizationExample(client);
            example.searchAndVectorize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
