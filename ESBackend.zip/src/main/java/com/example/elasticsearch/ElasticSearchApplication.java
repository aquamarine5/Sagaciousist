package com.example.elasticsearch;

import com.example.elasticsearch.controller.BookSearch;
import org.apache.http.HttpHost;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.elasticsearch.client.RestClient;

@SpringBootApplication
public class ElasticSearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElasticSearchApplication.class, args);
    }

    @Bean
    public CommandLineRunner init(BookSearch bookSearch) {
        return args -> {
            try (RestClient client = RestClient.builder(new HttpHost("localhost", 9200)).build()) {
                BookSearch example = new BookSearch(client);
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }
}