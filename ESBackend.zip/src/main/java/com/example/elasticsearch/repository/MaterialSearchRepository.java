package com.example.elasticsearch.repository;
import com.example.elasticsearch.entity.Material;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.annotations.Highlight;
import org.springframework.data.elasticsearch.annotations.HighlightField;
import org.springframework.data.elasticsearch.annotations.HighlightParameters;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
//MaterialSearchRepository 提供了一个高级的抽象，使得你可以在不编写任何实现代码的情况下，直接使用预定义的CRUD方法和查询方法。
public interface MaterialSearchRepository extends ElasticsearchRepository<Material, String> {
    @Highlight(
            fields = {@HighlightField(name = "title"), @HighlightField(name = "content")},
            parameters = @HighlightParameters(preTags = {"<span style='color:red'>"}, postTags = {"</span>"}, numberOfFragments = 0)
    )
    Page<Material> findByContent(String content, Pageable pageable);

}
