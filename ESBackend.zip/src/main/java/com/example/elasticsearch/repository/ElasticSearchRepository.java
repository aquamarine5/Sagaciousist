package com.example.elasticsearch.repository;
import com.example.elasticsearch.entity.Book;
import org.springframework.data.elasticsearch.annotations.Highlight;
import org.springframework.data.elasticsearch.annotations.HighlightField;
import org.springframework.data.elasticsearch.annotations.HighlightParameters;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
//ElasticsearchRepository 提供了一个高级的抽象，使得你可以在不编写任何实现代码的情况下，直接使用预定义的CRUD方法和查询方法。
public interface ElasticSearchRepository extends ElasticsearchRepository<Book, String> {
    /**
     * 查询内容标题查询
     * @param title 标题
     * @param content 内容
     * @return 返回关键字高亮的结果集
     */
    @Highlight(
            fields = {@HighlightField(name = "title"), @HighlightField(name = "content")},
            parameters = @HighlightParameters(preTags = {"<span style='color:red'>"}, postTags = {"</span>"}, numberOfFragments = 0)
    )

    List<SearchHit<Book>> findByTitleOrContent(String title, String content);


}

