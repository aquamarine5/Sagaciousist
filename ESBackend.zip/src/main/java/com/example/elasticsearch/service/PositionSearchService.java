package com.example.elasticsearch.service;

import com.example.elasticsearch.entity.Position;


public interface PositionSearchService {
    //保存和修改
    void save(Position article);

    //查询id
    //  ElasticSearch findById(Integer id);

    //删除指定ID数据
    void deleteById(String id);

    long count();

    boolean existsById(String id);

    // 新增批量上传文档的方法
    void batchUploadFromDirectory(String directoryPath);

}
