package com.example.elasticsearch.service.impl;
import com.example.elasticsearch.entity.Position;
import com.example.elasticsearch.repository.PositionSearchRepository;
import com.example.elasticsearch.service.PositionSearchService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

@Service
public class PositionSearchServiceImpl implements PositionSearchService {

    private final PositionSearchRepository positionSearchRepository;

    @Autowired
    public PositionSearchServiceImpl(PositionSearchRepository positionSearchRepository) {
        this.positionSearchRepository = positionSearchRepository;
    }

    @Resource
    private PositionSearchRepository PositionSearchRepository;

    @Override
    public void save(Position Position){
        PositionSearchRepository.save(Position);
    }


    @Override
    public void deleteById(String id) {
        PositionSearchRepository.deleteById(id);
    }

    @Override
    public long count() {
        return PositionSearchRepository.count();
    }


    @Override
    public boolean existsById(String id) {
        return PositionSearchRepository.existsById(id);
    }

//     批量读取Excel文件
    @Override
    public void batchUploadFromDirectory(String directoryPath) {
        File file = new File(directoryPath);
        try (FileInputStream fis = new FileInputStream(file)) {
            Workbook workbook = new HSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // 假设我们只处理第一个sheet
            Iterator<Row> rowIterator = sheet.iterator();

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                if (row.getRowNum() == 0) continue; // 跳过标题行
                Iterator<Cell> cellIterator = row.cellIterator();
                Position Position = new Position(
                        (int) getIntValue(cellIterator.next()),// 假设第一列是ID
                        getStringValue(cellIterator.next()), // 第二列是标题
                        getStringValue(cellIterator.next())  // 第三列是内容
                );
                save(Position); // 调用现有的保存方法
                System.out.println("保存成功");
            }
        } catch (IOException e) {
            System.err.println("读取excel文件失败: " + file.getName());
            // 处理异常
            e.printStackTrace();
        }
    }


    // 读取CSV文件
//    @Override
//    public void batchUploadFromDirectory(String directoryPath) {
//        File file = new File(directoryPath);
//        try (CSVReader reader = new CSVReader(new FileReader(file))) {
//            String[] line;
//            while ((line = reader.readNext()) != null) {
//                if (reader.getLinesRead() == 1) continue; // 跳过标题行
//                if (line.length < 3) continue; // 确保有足够多的列
//                Position Position = new Position(
//                        Integer.parseInt(line[0]), // 假设第一列是ID
//                        line[1], // 第二列是标题
//                        line[2]  // 第三列是内容
//                );
//                save(Position); // 调用现有的保存方法
//                System.out.println("保存成功");
//            }
//        } catch (IOException | CsvValidationException e) {
//            System.err.println("读取CSV文件失败: " + file.getName());
//            // 处理异常
//            e.printStackTrace();
//        }
//    }

    private long getIntValue(Cell next) {
        return (long) next.getNumericCellValue();
    }

    private String getStringValue(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf((int)cell.getNumericCellValue());
        }
        return "";
    }
}

