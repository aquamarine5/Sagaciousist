package com.example.elasticsearch.service.impl;

import com.example.elasticsearch.entity.Book;
import com.example.elasticsearch.service.ElasticSearchService;
import com.example.elasticsearch.repository.ElasticSearchRepository;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import static org.apache.commons.collections4.MapUtils.getIntValue;

@Service
public class ElasticSearchServiceImpl implements ElasticSearchService {

    private final ElasticSearchRepository elasticSearchRepository;


    @Autowired
    public ElasticSearchServiceImpl(ElasticSearchRepository elasticSearchRepository) {
        this.elasticSearchRepository = elasticSearchRepository;
    }

    @Resource
    private ElasticSearchRepository ElasticSearchRepository;


    @Override
    public void save(Book book) {
        ElasticSearchRepository.save(book);
    }


    @Override
    public void deleteById(String id) {
        ElasticSearchRepository.deleteById(id);
    }

    @Override
    public long count() {
        return ElasticSearchRepository.count();
    }


    @Override
    public boolean existsById(String id) {
        return ElasticSearchRepository.existsById(id);
    }


    @Override
    public void batchUploadFromDirectory(String directoryPath) {
        File file = new File(directoryPath);
                    try (FileInputStream fis = new FileInputStream(file)) {
                        Workbook workbook = new HSSFWorkbook(fis);
                        Sheet sheet = workbook.getSheetAt(0); // 假设我们只处理第一个sheet
                        Iterator<Row> rowIterator = sheet.iterator();

                        while (rowIterator.hasNext()) {
                            Row row = rowIterator.next();
                            if (row.getRowNum() == 0) continue; // 跳过标题行
                            Iterator<Cell> cellIterator = row.cellIterator();
                            Book book = new Book(
                                    (int) getIntValue(cellIterator.next()),// 假设第一列是ID
                                    getStringValue(cellIterator.next()), // 第二列是标题
                                    getStringValue(cellIterator.next())  // 第三列是内容
                            );
                            save(book); // 调用现有的保存方法
                            System.out.println("保存成功");
                        }
                    } catch (IOException e) {
                        System.err.println("读取excel文件失败: " + file.getName());
                        // 处理异常
                        e.printStackTrace();
                    }
                }

    private long getIntValue(Cell next) {
        return (long) next.getNumericCellValue();
    }

    private String getStringValue(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf((int)cell.getNumericCellValue());
        }
        return "";
    }

}

