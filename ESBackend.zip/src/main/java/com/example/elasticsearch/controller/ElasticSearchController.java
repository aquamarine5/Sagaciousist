package com.example.elasticsearch.controller;
import com.example.elasticsearch.entity.Book;
import com.example.elasticsearch.service.ElasticSearchService;
import com.example.elasticsearch.service.MaterialSearchService;
import com.example.elasticsearch.service.PositionSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import java.text.SimpleDateFormat;


@RestController
public class ElasticSearchController {
    @Resource
    private ElasticSearchService elasticSearchService;

    @Resource
    private MaterialSearchService materialSearchService;

    @Resource
    private PositionSearchService positionSearchService;

    @Qualifier("elasticSearchRepository")
    @Autowired
    private ElasticsearchRepository elasticsearchRepository;
    //保存单个文档
    @RequestMapping("/save")
    public String save() throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Book book = new Book(1, "资治通鉴", "阿斯顿附件为u染发剂角度上考虑成本v居委会");
        elasticSearchService.save(book);
        return "success";
    }
    @RequestMapping("/bookInit")
    public String init() {
        elasticSearchService.batchUploadFromDirectory("D:\\数据\\资治通鉴问答文档.xls");
        return "success";
    }


    @RequestMapping("/materialInit")
    public String materialInit() {
        materialSearchService.batchUploadFromDirectory("   ");
        return "success";
    }

    @RequestMapping("/positionInit")
    public String positionInit() {
        positionSearchService.batchUploadFromDirectory("D:\\数据\\资治通鉴问答文档.xls");
        return "success";
    }

}

