
package com.example.elasticsearch.controller;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;
import org.apache.http.util.EntityUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

@RestController
public class PositionSearch {

    private RestClient client;

    public PositionSearch(RestClient client) {
        this.client = client;
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/positionSearch")
    public List<List<List<Map<String, Object>>>> search(@RequestParam(value = "query" , required = false) String query){
        try {
            System.out.println("Received query parameter: " + query+"    ----");
            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            sourceBuilder.query(QueryBuilders.matchAllQuery());
            Request request = new Request("GET", "/position_index/_search");
            sourceBuilder.size(100);
            request.setJsonEntity(sourceBuilder.toString());
            Response response = client.performRequest(request);
            String jsonString = EntityUtils.toString(response.getEntity(), "UTF-8");
            JsonNode root = new ObjectMapper().readTree(jsonString);
            JsonNode hits = root.get("hits");
            JsonNode hitsArray = hits.get("hits");
            List<Map<String, Object>> results = new ArrayList<>();

            Map<String, Integer> globalWordCount = new HashMap<>();
            for (JsonNode hit : hitsArray) {
                JsonNode sourceNode = hit.get("_source");
                Map sourceMap = new ObjectMapper().convertValue(sourceNode, Map.class);
                Map<String, Object> hitMap = new HashMap<>();
                hitMap.put("_index", hit.get("_index").asText());
                hitMap.put("_id", hit.get("_id").asText());
                hitMap.put("_score", hit.get("_score").asDouble());
                hitMap.put("_source", sourceMap);
                results.add(hitMap);

                String textFieldValue = (String) sourceMap.get("title");
                List<String> words = tokenizeText(textFieldValue);
                for (String word : words) {
                    if (word != null) {
                        globalWordCount.put(word, globalWordCount.getOrDefault(word, 0) + 1);
                    }
                }
            }

            List<String> globalVocabulary = new ArrayList<>(globalWordCount.keySet());
            //打印全部词
            System.out.println("全局词表: " + globalVocabulary);

            List<String> stopWords = importStopWordsFromCSV("src/main/resources/resource/template_words.csv");
//            System.out.println("停用词列表: " + stopWords);

            for (String word : stopWords) {
                globalVocabulary.remove(word);
            }
//
//            System.out.println("全局词表: " + globalVocabulary);
//            Collections.sort(globalVocabulary);

            int totalDocuments = hitsArray.size();
            Map<String, Double> idfMap = new HashMap<>();
            for (String word : globalVocabulary) {
                int df = globalWordCount.get(word);
                double idf = Math.log((double) totalDocuments / df);
                idfMap.put(word, idf);
            }

            List<String> searchwords = tokenizeText(query);
            for (String word : stopWords) {
                searchwords.remove(word);
            }
            Double[] searchVector = textToVectorTFIDF(searchwords, globalVocabulary, idfMap);

            List<Map.Entry<Map<String, Object>, Double>> similarities = new ArrayList<>();
            for (Map<String, Object> hit : results) {
                Map<String, Object> source = (Map<String, Object>) hit.get("_source");
                String textFieldValue = (String) source.get("title");
                List<String> words = tokenizeText(textFieldValue);
                Double[] vector = textToVectorTFIDF(words, globalVocabulary, idfMap);
                double similarity = cosineSimilarity(searchVector, vector);
                similarities.add(new AbstractMap.SimpleEntry<>(hit, similarity));
            }

            similarities.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
            Map.Entry<Map<String, Object>, Double> highestSimilarityEntry = similarities.get(0);
//            System.out.println("相似度最高的文档:");
//            System.out.println("索引: " + highestSimilarityEntry.getKey().get("_index"));
//            System.out.println("ID: " + highestSimilarityEntry.getKey().get("_id"));
//            System.out.println("标题: " + ((Map<String, Object>) highestSimilarityEntry.getKey().get("_source")).get("title"));
//            System.out.println("内容: " + ((Map<String, Object>) highestSimilarityEntry.getKey().get("_source")).get("content"));
//            System.out.println("相似度: " + highestSimilarityEntry.getValue());

            List<List<Map<String, Object>>> result = new ArrayList<>();
            if (similarities.isEmpty() || similarities.get(0).getValue() < 0.5) {
                System.out.println("没有相似度大于0.5的文档");
                return  Collections.singletonList(result);
            } else {
                result.add(createSuccessResponse(highestSimilarityEntry));
                System.out.println("相似度最高的文档: " + result);
                return Collections.singletonList(result);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.singletonList(Collections.singletonList(Collections.singletonList((Map<String, Object>) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing search request."))));
        }
    }

    List<Map<String, Object>> createSuccessResponse(Map.Entry<Map<String, Object>, Double> entry) {
        List<Map<String, Object>> response = new ArrayList<>();
        Map<String, Object> result = new HashMap<>();
        result.put("status", "success");
        result.put("index", entry.getKey().get("_index"));
        result.put("id", entry.getKey().get("_id"));
        result.put("title", ((Map<String, Object>) entry.getKey().get("_source")).get("title"));
        result.put("content", ((Map<String, Object>) entry.getKey().get("_source")).get("content"));
        result.put("similarity", entry.getValue());
        response.add(result);
        return response;
    }


    private List<String> importStopWordsFromExcel(String filePath) throws IOException {
        List<String> stopWordsSet = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new HSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                for (Cell cell : row) {
                    if (cell.getCellType() == CellType.STRING) {
                        stopWordsSet.add(cell.getStringCellValue().trim());
                    }
                }
            }
        }
        return stopWordsSet;
    }
    // 导入CSV文件
    private List<String> importStopWordsFromCSV(String filePath) throws IOException {
        List<String> stopWordsSet = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] cells = line.split(",");
                for (String cell : cells) {
                    if (cell != null && !cell.trim().isEmpty()) {
                        stopWordsSet.add(cell.trim());
                    }
                }
            }
        }
        return stopWordsSet;
    }

    private List<String> tokenizeText(String textFieldValue) {
        List<Term> termList = HanLP.segment(textFieldValue);
        List<String> words = new ArrayList<>();

        for (Term term : termList) {
            String word = term.word;
            if (removeSymbolsOnlyWords(word) != " ") {
                words.add(word);
            }
        }
        return words;
    }

    private Double[] textToVectorTFIDF(List<String> words, List<String> globalVocabulary, Map<String, Double> idfMap) {
        int vocabSize = globalVocabulary.size();
        Double[] vector = new Double[vocabSize];
        Map<String, Integer> wordCount = new HashMap<>();
        for (String word : words) {
            word = removeSymbolsOnlyWords(word);
            if (word != null) {
                wordCount.put(word, wordCount.getOrDefault(word, 50) + 1);
            }
        }
        for (int i = 0; i < vocabSize; i++) {
            String word = globalVocabulary.get(i);
            double tf = wordCount.getOrDefault(word, 1);
            double idf = idfMap.getOrDefault(word, 0.01);
            vector[i] = (tf * idf);
        }
        return vector;
    }

    private String removeSymbolsOnlyWords(String word) {
        Pattern chinesePattern = Pattern.compile("^[\u4e00-\u9fa5]+$");
        return chinesePattern.matcher(word).matches() ? word : " ";
    }

    private static double cosineSimilarity(Double[] vectorA, Double[] vectorB) {
        double dotProduct = 0.0;
        double magnitudeA = 0.0;
        double magnitudeB = 0.0;
        for (int i = 0; i < vectorB.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            magnitudeA += Math.pow(vectorA[i], 2);
            magnitudeB += Math.pow(vectorB[i], 2);
        }
        magnitudeA = Math.sqrt(magnitudeA);
        magnitudeB = Math.sqrt(magnitudeB);
        if (magnitudeA == 0.0 || magnitudeB == 0.0) {
            return 0.0;
        }
        return dotProduct / (magnitudeA * magnitudeB);
    }
}