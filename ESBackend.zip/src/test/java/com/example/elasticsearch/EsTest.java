package com.example.elasticsearch;
import com.example.elasticsearch.service.ElasticSearchService;
//import com.example.elasticsearch.service.MaterialSearchService;
import com.example.elasticsearch.service.MaterialSearchService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.test.context.junit4.SpringRunner;
import javax.annotation.Resource;


@RunWith(SpringRunner.class)
@SpringBootApplication
public class EsTest {

    @Resource
    private ElasticSearchService elasticSearchService;

    @Resource
    private MaterialSearchService materialSearchService;



//    /**添加文档或者修改文档(以id为准)*/
//    @Test
//    public void saveElasticSearch(){
//        Book elasticSearch = new Book();
//        elasticSearch.setId(1);
//        elasticSearch.setTitle(" 天下武功，唯快不破");
//        elasticSearch.setContent("天下武功，为哦快步破碎的和解放军，洒家扩大发挥好");
//        elasticSearchService.save(elasticSearch);
//    }
//
//    // 添加
//    @Test
//    public void saveElasticSearch1(){
//        Book elasticSearch = new Book();
//        elasticSearch.setId(4);
//        elasticSearch.setTitle(" 天下武功，唯快不破");
//        elasticSearch.setContent("天下武功，为哦快步破碎的和解放军，洒家扩大发挥好");
//        elasticSearchService.save(elasticSearch);
//    }

    /**删除文档(以id为准)*/
//    @Test
//    public void deleteById(){
//        elasticSearchService.deleteById("1");
//    }
//    @Test
//    public void deleteById1(){
//        elasticSearchService.deleteById("2");
//    }
//    @Test
//    public void deleteById2(){
//        elasticSearchService.deleteById("3");
//    }
//    @Test
//    public void deleteById3(){
//        elasticSearchService.deleteById("4");
//    }
    @Test
    public void deleteById4(){
        elasticSearchService.deleteById("33");
    }


//    /**计算文档总个数(以id为准)*/
//    @Test
//    public void count(){
//        long count = elasticSearchService.count();
//        System.out.println(count);
//    }
//    /**判断是否存在(以id为准)*/
//    @Test
//    public void existsById(){
//        boolean b = elasticSearchService.existsById("1");
//        System.out.println(b);
//    }

//    /**查询文档(模糊查询)*/
//    @Test
//    public void findByTitleOrContent(){
//        List<SearchHit<Book>> byTitleOrContent = elasticSearchService.findByTitleOrContent("XXX","XXX");
//        for (SearchHit<Book> elasticSearchService : byTitleOrContent) {
//            List<String> title = elasticSearchService.getHighlightField("title");
//            System.out.println(title);
//            List<String> content = elasticSearchService.getHighlightField("content");
//            System.out.println(content);
//
//        }
//    }
    /**批量上传(导入文件·1)*/
    @Test
    public void batchUploadBookFromDirectory(){
        elasticSearchService.batchUploadFromDirectory("D:\\数据\\资治通鉴问答文档.xls");
    }

//    @Test
//    public void batchUploadMaterialFromDirectory(){
//        materialSearchService.batchUploadFromDirectory("D:\\数据\\material.xls");
//    }
}

