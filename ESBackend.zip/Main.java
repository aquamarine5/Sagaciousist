package com.example.es.controller;

import java.io.IOException;
import java.util.List;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.IndexResponse;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import com.example.es.entity.ElasticSearch;

import org.apache.http.HttpHost;

import org.elasticsearch.client.RestClient;


public class Main {
    public static void main(String[] args) {
        try {
            ExcelReader excelReader = new ExcelReader();
            // 读取 Excel 文件
            List<ElasticSearch> documents = excelReader.readExcelFile("C:/Users/zhang/Desktop/es.xlsx");

            // 创建 RestClient 实例
            RestClient restClient = RestClient.builder(
                    new HttpHost("localhost", 9200, "http")).build();

            // 创建 ElasticsearchTransport 实例
            ElasticsearchTransport transport = new RestClientTransport(
                    restClient, new JacksonJsonpMapper());

            // 创建 ElasticsearchClient 实例
            ElasticsearchClient client = new ElasticsearchClient(transport);

            // 索引数据
            for (ElasticSearch document : documents) {
                IndexResponse indexResponse = client.index(i -> i
                        .index("3")
                        .id(document.getId())
                        .document(document));

                // 输出响应结果
                assert indexResponse != null;
                System.out.println("Index response: " + indexResponse.result());
            }

            // 关闭客户端
             restClient.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}